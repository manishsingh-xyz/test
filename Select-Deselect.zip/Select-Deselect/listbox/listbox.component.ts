import { Component, OnInit } from '@angular/core';

import { TestserviceService } from '../testservice.service';
import { Test } from '../test';
import { AVALIABLE, CURRENT } from '../testdata';

@Component({
  selector: 'app-listbox',
  templateUrl: './listbox.component.html',
  styleUrls: ['./listbox.component.css']
})
export class ListboxComponent implements OnInit {
  availablelist: Test[];
  currentlist: Test[];
  avaliableSelectedView: string;
  currentSelectedView: string;
  addedValue: any;
  indexValue: number;
  constructor(private testService: TestserviceService) { }
  
  ngOnInit() {
    this.getData();
  }

  getData(): void {
    this.testService.getAvailableViewData()
    .subscribe(productdata => {
        this.availablelist = productdata[0].results;
      });

    this.testService.getCurrentViewData()
    .subscribe(productdata => {
        this.currentlist = productdata[0].results;
      });  
  }

  addData(): void {
    if(this.avaliableSelectedView) {
      this.currentlist.push(this.addedValue);
      if (this.indexValue > -1) {
        this.availablelist.splice(this.indexValue, 1);
      }
    }
    else if(this.currentSelectedView) {
      alert('Please select data from Available views to add in Current views');
    }
    this.avaliableSelectedView = null;
  }

  removeData(): void {
    if(this.currentSelectedView && this.addedValue.required !== true) {
      this.availablelist.push(this.addedValue);
      if (this.indexValue > -1) {
        this.currentlist.splice(this.indexValue, 1);
      }
    }
    else if(this.avaliableSelectedView) {
      alert('Please select data from Current views to remove');
    }
    else if(this.currentSelectedView && this.addedValue.required === true) {
      alert('This is required view cannot be removed');
    }
    this.currentSelectedView = null;
  }

  onAvaliableListChange(d, i): void {
    this.currentSelectedView = null;
    this.addedValue = d;
    this.indexValue = i    
  }

  onCurrentListChange(d, i): void {
    this.avaliableSelectedView = null;
    this.addedValue = d;
    this.indexValue = i;
  }


};
