export class Test {
    results: any;
}
